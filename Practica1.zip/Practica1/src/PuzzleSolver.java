import java.util.ArrayList;

/**
 * @author Enrique Garcia Gutierrez
 * @author Sergio Ruiz Pe�a
 */


public class PuzzleSolver {
	/**
	 * Arraylist con los tableros explorados
	 */
	private ArrayList<String> tableros = new ArrayList<String>();
	/**
	 * Contador de iteraciones para evitar bucles infinitos.
	 * Puesto que esta demostrado que todos los puzzles se 
	 * pueden resolver con 32 movimientos o menos, este sera 
	 * el mayor valor que podra tomar esta variable.
	 */
	int iteraciones = 0;
	/**
	 * Array auxiliar con los desplazamientos relativos de fila
	 */
	static int[] movFil = {-1,1,0,0}; //ud
	/**
	 * Array auxiliar con los desplazamientos relativos de columna
	 */
	static int[] movCol = {0,0,1,-1}; //rl
	
	
	/**
	 * Constructor generico
	 */
	public PuzzleSolver(){}
	
	/**
	 * 
	 * @param puzzle
	 * @return
	 */
	public boolean isSolved(Puzzle puzzle){
		for(int i=0;i<puzzle.FILAS;i++){
			for(int j=0;j<puzzle.COLUMNAS;j++){
				
			}
		}
		return true;
	}
	
	/**
	 * Metodo que resuelve el puzzle pasado por backtracking.
	 * Por lo general, suele tardar del orden de 10 minutos en resolver un puzzle de 3x3
	 * @param puzzle Puzzle a resolver
	 * @param fil Fila donde se encuentra en ese momento el hueco
	 * @param col Columna donde se encuentra en ese momento el hueco
	 * @param puzzleSolucion Puzzle con la solucion del puzzle
	 * @return true si lo ha resuelto
	 * @throws Exception 
	 */
	public boolean backtrack (Puzzle puzzle, int fil, int col, Puzzle solucion) {
		boolean exito = false;
		if (puzzle.igual(solucion))
			return true;
		int i = -1;
		boolean repetido = false;
		while (!exito && i!=3){
			i++;
			int deltaFil = fil + movFil[i];
			int deltaCol = col + movCol[i];
			if (deltaFil >= 0 && deltaFil < puzzle.FILAS && deltaCol >= 0 && deltaCol < puzzle.COLUMNAS) {
				puzzle = puzzle.mover(puzzle, fil, col, deltaFil, deltaCol);
				for (String pz: tableros) {
					if(puzzle.representar().equals(pz)) {
						repetido = true;
						break;
					}
				}
				if(!repetido) {
					tableros.add(puzzle.representar());
					if (puzzle.igual(solucion)) {
						exito = true;
					}
					else {
						if (iteraciones <= 32) {
							iteraciones++;
							exito = backtrack(puzzle, deltaFil, deltaCol, solucion);
							if (!exito) {
								puzzle = puzzle.mover(puzzle, fil, col, deltaFil, deltaCol);
								iteraciones--;
							}
						}
						else {
							puzzle.mover(puzzle, fil, col, deltaFil, deltaCol);
							exito = false;
						}
					}
				}
				else {
					puzzle.mover(puzzle, fil, col, deltaFil, deltaCol);
					repetido = false;
					exito = false;
				}
			}				
		}
		if (exito) {
			System.out.println("Hueco: {" + fil + "," + col + "}");
		}
		return exito;
	}
	
	/**
	 * Metodo main de la clase PuzzleSolver. Resuelve el puzzle creado 
	 * a partir del archivo de texto introducido.
	 * @param args Argumento del main
	 */
	public static void main (String[] args) {
		PuzzleSolver ps = new PuzzleSolver();
		Puzzle p = new Puzzle("puzle.txt");
		ps.tableros.add(p.representar());
		Puzzle puzleSolucion = new Puzzle(p.solucion());
		
		int[] posNull = p.getPosicion("-");
		if (ps.backtrack(p, posNull[0], posNull[1], puzleSolucion))
			System.out.println("Bieeeeen");
		else
			System.out.println("Maaaaaaal");
		
	}
}
